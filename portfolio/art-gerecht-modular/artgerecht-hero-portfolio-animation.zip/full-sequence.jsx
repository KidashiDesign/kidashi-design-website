// Sequences all 7 AGM brand-frame animations into one continuous, looping reel.
// Each scene is driven purely by useScene().progress so host time-stretch/export work.

function kf(t, stops) {
  if (t <= stops[0][0]) return stops[0][1];
  for (var i = 0; i < stops.length - 1; i++) {
    var t0 = stops[i][0], v0 = stops[i][1];
    var t1 = stops[i + 1][0], v1 = stops[i + 1][1];
    if (t <= t1) {
      var f = (t1 === t0) ? 0 : (t - t0) / (t1 - t0);
      return v0 + (v1 - v0) * f;
    }
  }
  return stops[stops.length - 1][1];
}

// Wraps every scene with a black overlay that is fully opaque at progress 0 and 1
// (a settled state) and transparent through the middle -- gives clean cross-cuts
// between scenes regardless of each scene's own choreography.
function SceneFade(props) {
  var t = props.progress;
  var fadeIn = props.fadeIn != null ? props.fadeIn : 0.08;
  var fadeOut = props.fadeOut != null ? props.fadeOut : 0.08;
  var overlay = kf(t, [[0, 1], [fadeIn, 0], [1 - fadeOut, 0], [1, 1]]);
  return React.createElement(
    'div',
    { style: { position: 'absolute', inset: 0, overflow: 'hidden', background: '#000' } },
    props.children,
    React.createElement('div', { style: { position: 'absolute', inset: 0, background: '#000', opacity: overlay, pointerEvents: 'none', zIndex: 50 } })
  );
}

// ── 1. Intro logo ────────────────────────────────────────────────────────────
function IntroScene() {
  var t = window.useScene().progress;
  var bgOpacity = kf(t, [[0, 0], [0.15, 1], [0.85, 1], [0.95, 0], [1, 0]]);
  var bgScale = kf(t, [[0, 1.12], [0.15, 1.02], [0.5, 1.07], [0.85, 1.1], [1, 1.13]]);
  var bgTx = kf(t, [[0, 0], [0.15, -0.6], [0.5, 0.5], [0.85, 0], [1, 0]]);
  var bgTy = kf(t, [[0, 0], [0.15, 0.2], [0.5, -0.4], [0.85, 0], [1, 0]]);
  var vig = kf(t, [[0, 0.35], [0.15, 0.55], [0.5, 0.6], [0.85, 0.55], [1, 0.35]]);
  var logoOpacity = kf(t, [[0, 0], [0.14, 0], [0.34, 1], [0.8, 1], [0.92, 0], [1, 0]]);
  var logoScale = kf(t, [[0, 1.65], [0.14, 1.65], [0.34, 1], [0.8, 1], [0.92, 1.55], [1, 1.65]]);
  var logoBlur = kf(t, [[0, 30], [0.14, 30], [0.34, 0], [0.8, 0], [0.92, 24], [1, 30]]);
  var logoClip = kf(t, [[0, 0], [0.14, 0], [0.34, 85], [0.8, 85], [0.92, 0], [1, 0]]);

  return React.createElement(
    SceneFade, { progress: t },
    React.createElement(
      'div', { style: { position: 'absolute', inset: 0, background: '#0b0a08' } },
      React.createElement('img', { src: 'media/AGM_1.webp', style: { position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', opacity: bgOpacity, transform: 'scale(' + bgScale + ') translate(' + bgTx + '%,' + bgTy + '%)' } }),
      React.createElement('div', { style: { position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 50%, rgba(0,0,0,0) 38%, rgba(0,0,0,0.55) 100%)', opacity: vig } }),
      React.createElement(
        'div', { style: { position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' } },
        React.createElement('img', { src: 'media/AGM_1.2.webp', alt: 'Art Gerecht Modular', style: { height: '60%', width: 'auto', opacity: logoOpacity, transform: 'scale(' + logoScale + ')', filter: 'blur(' + logoBlur + 'px) drop-shadow(0 18px 50px rgba(0,0,0,0.55))', clipPath: 'circle(' + logoClip + '% at 50% 50%)' } })
      )
    )
  );
}

// ── 2. Tech graphic grid ─────────────────────────────────────────────────────
function TechGridScene() {
  var t = window.useScene().progress;
  var vPositions = [12.5, 25, 37.5, 50, 62.5, 75, 87.5];
  var hPositions = [16.66, 33.33, 50, 66.66, 83.33];
  var lineColor = 'rgba(20,18,14,0.16)';
  var logoOpacity = kf(t, [[0, 0], [0.42, 0], [0.56, 1], [0.8, 1], [0.94, 0], [1, 0]]);
  var logoScale = kf(t, [[0, 0.82], [0.42, 0.82], [0.56, 1], [0.8, 1], [0.94, 1.05], [1, 1.05]]);

  var vLines = vPositions.map(function (pos, i) {
    var start = 0.16 + i * 0.02, end = start + 0.12;
    var op = kf(t, [[0, 0], [start, 0], [end, 1], [0.8, 1], [0.9, 0], [1, 0]]);
    return React.createElement('div', { key: 'v' + i, style: { position: 'absolute', top: 0, left: pos + '%', width: 1, height: '100%', background: lineColor, opacity: op, transform: 'scaleY(' + op + ')', transformOrigin: 'top' } });
  });
  var hLines = hPositions.map(function (pos, i) {
    var start = 0.30 + i * 0.02, end = start + 0.12;
    var op = kf(t, [[0, 0], [start, 0], [end, 1], [0.8, 1], [0.9, 0], [1, 0]]);
    return React.createElement('div', { key: 'h' + i, style: { position: 'absolute', left: 0, top: pos + '%', height: 1, width: '100%', background: lineColor, opacity: op, transform: 'scaleX(' + op + ')', transformOrigin: 'left' } });
  });

  return React.createElement(
    SceneFade, { progress: t },
    React.createElement(
      'div', { style: { position: 'absolute', inset: 0, background: '#f8f6ee' } },
      React.createElement('img', { src: 'media/AGM_2.webp', style: { position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover' } }),
      React.createElement('div', { style: { position: 'absolute', inset: 0 } }, vLines.concat(hLines)),
      React.createElement(
        'div', { style: { position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%) scale(' + logoScale + ')', opacity: logoOpacity } },
        React.createElement('img', { src: 'media/AGM_2.2.webp', alt: 'Modular logo', style: { height: '80vh', width: 'auto', maxWidth: '144vw' } })
      )
    )
  );
}

// ── 3. Truck outside view ────────────────────────────────────────────────────
function TruckScene() {
  var t = window.useScene().progress;
  var imgRef = React.useRef(null);
  var turbRef = React.useRef(null);
  var dispRef = React.useRef(null);
  var wave = (1 - Math.cos(2 * Math.PI * t)) / 2;
  var zoomAmount = 1.15, morphIntensity = 22;
  var scale = 1 + (zoomAmount - 1) * wave;
  var freq = 0.006 + 0.01 * wave;
  var dispScale = morphIntensity * wave;

  React.useEffect(function () {
    if (imgRef.current) imgRef.current.style.transform = 'scale(' + scale.toFixed(4) + ')';
    if (turbRef.current) turbRef.current.setAttribute('baseFrequency', freq.toFixed(4) + ' ' + (freq * 1.4).toFixed(4));
    if (dispRef.current) dispRef.current.setAttribute('scale', dispScale.toFixed(2));
  });

  return React.createElement(
    SceneFade, { progress: t },
    React.createElement(
      'div', { style: { position: 'absolute', inset: 0, background: '#0b0b0a' } },
      React.createElement(
        'svg', { width: 0, height: 0, style: { position: 'absolute' } },
        React.createElement(
          'defs', null,
          React.createElement(
            'filter', { id: 'truckMorphFilter', x: '-20%', y: '-20%', width: '140%', height: '140%' },
            React.createElement('feTurbulence', { ref: turbRef, type: 'fractalNoise', baseFrequency: '0.008 0.011', numOctaves: 2, seed: 7, result: 'noise' }),
            React.createElement('feDisplacementMap', { ref: dispRef, in: 'SourceGraphic', in2: 'noise', scale: 0, xChannelSelector: 'R', yChannelSelector: 'G' })
          )
        )
      ),
      React.createElement('img', { ref: imgRef, src: 'media/AGM_3.webp', alt: 'Overlanding expedition truck collage', style: { position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', filter: 'url(#truckMorphFilter)', transformOrigin: '50% 58%' } })
    )
  );
}

// ── 4. Grid logo build ───────────────────────────────────────────────────────
function GridLogoScene() {
  var t = window.useScene().progress;
  var cols = 9, rows = 5;
  var centerR = Math.ceil(rows / 2), centerC = Math.ceil(cols / 2);
  var colStart = centerC - 1, colEnd = colStart + 3;
  var rowStart = 2, rowEnd = 5;
  var lineRgba = 'rgba(255,255,255,0.5)';
  var logoOpacity = kf(t, [[0, 0], [0.22, 0], [0.38, 1], [0.78, 1], [0.92, 0], [1, 0]]);
  var logoScale = kf(t, [[0, 0.8], [0.22, 0.8], [0.38, 1], [0.78, 1], [0.92, 0.8], [1, 0.8]]);

  var cellDivs = [];
  for (var r = 1; r <= rows; r++) {
    for (var c = 1; c <= cols; c++) {
      var inLogo = r >= rowStart && r < rowEnd && c >= colStart && c < colEnd;
      if (inLogo) continue;
      var dist = Math.max(Math.abs(r - centerR), Math.abs(c - centerC));
      var delay = dist * 0.025;
      var start = 0.02 + delay, end = start + 0.12;
      var op = kf(t, [[0, 0], [start, 0], [end, 1], [0.8, 1], [0.94, 0], [1, 0]]);
      var sc = 0.4 + 0.6 * op;
      cellDivs.push(React.createElement('div', { key: r + '-' + c, style: { gridRow: r, gridColumn: c, border: '1px solid ' + lineRgba, boxSizing: 'border-box', opacity: op, transform: 'scale(' + sc + ')' } }));
    }
  }

  return React.createElement(
    SceneFade, { progress: t },
    React.createElement(
      'div', { style: { position: 'absolute', inset: 0, background: '#E39A00', fontFamily: 'Helvetica,Arial,sans-serif' } },
      React.createElement(
        'div', { style: { position: 'absolute', inset: 0, display: 'grid', gridTemplateColumns: 'repeat(' + cols + ',1fr)', gridTemplateRows: 'repeat(' + rows + ',1fr)' } },
        cellDivs.concat([
          React.createElement(
            'div', { key: 'logo', style: { gridRow: rowStart + ' / ' + rowEnd, gridColumn: colStart + ' / ' + colEnd, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '4%', boxSizing: 'border-box', opacity: logoOpacity, transform: 'scale(' + logoScale + ')' } },
            React.createElement('img', { src: 'media/AGM_4.3.webp', alt: 'Art Gerecht Modular logo', style: { width: '100%', height: '100%', objectFit: 'contain', filter: 'drop-shadow(0 6px 20px rgba(0,0,0,0.18))' } })
          )
        ])
      )
    )
  );
}

// ── 5. Boat interior zoom ────────────────────────────────────────────────────
function BoatScene() {
  var t = window.useScene().progress;
  var eased = 0.5 - 0.5 * Math.cos(Math.PI * t);
  var scale = 1 + 0.14 * eased;
  var tx = -3 * eased, ty = 2 * eased;
  return React.createElement(
    SceneFade, { progress: t },
    React.createElement(
      'div', { style: { position: 'absolute', inset: 0, overflow: 'hidden', background: '#000' } },
      React.createElement('img', { src: 'media/AGM_5.webp', alt: '', style: { position: 'absolute', top: '50%', left: '50%', width: '100%', height: '100%', objectFit: 'cover', transform: 'translate(-50%,-50%) translate(' + tx + '%,' + ty + '%) scale(' + scale + ')' } })
    )
  );
}

// ── 6. Flyer reveal ──────────────────────────────────────────────────────────
function FlyerScene() {
  var t = window.useScene().progress;
  var zf = 0.09, df = 0.28;
  var wave = Math.sin(t * Math.PI);
  var wave2 = Math.sin(t * Math.PI * 2);
  var scale = 1.12 + wave * zf * 0.22;
  var panX = wave2 * zf * 26;
  var panY = wave * zf * -16;
  var rotY = wave2 * df * 7;
  var rotX = -wave * df * 5;
  return React.createElement(
    SceneFade, { progress: t },
    React.createElement(
      'div', { style: { position: 'absolute', inset: 0, overflow: 'hidden', background: '#dcdcdc', perspective: 2200 } },
      React.createElement('img', { src: 'media/AGM_6.webp', alt: '', style: { position: 'absolute', inset: '-8%', width: '116%', height: '116%', objectFit: 'cover', transform: 'scale(' + scale + ') translate3d(' + panX + 'px,' + panY + 'px,0) rotateX(' + rotX + 'deg) rotateY(' + rotY + 'deg)' } }),
      React.createElement('div', { style: { position: 'absolute', inset: 0, boxShadow: 'inset 0 -180px 220px -160px rgba(0,0,0,0.3)' } })
    )
  );
}

// ── 7. Logo outro ────────────────────────────────────────────────────────────
function OutroScene() {
  var t = window.useScene().progress;
  var bgScale = 1 + 0.14 * t;
  var scrimOp = kf(t, [[0, 0.10], [0.14, 0.10], [0.30, 0.62], [0.5, 0.62], [0.66, 0.10], [1, 0.10]]);
  var logoOp = kf(t, [[0, 0], [0.14, 0], [0.3, 1], [0.5, 1], [0.66, 0], [1, 0]]);
  var logoBlur = kf(t, [[0, 18], [0.14, 18], [0.3, 0], [0.5, 0], [0.66, 14], [1, 18]]);
  var logoScale = kf(t, [[0, 0.82], [0.14, 0.82], [0.3, 1], [0.5, 1], [0.66, 1.1], [1, 0.82]]);
  return React.createElement(
    SceneFade, { progress: t },
    React.createElement(
      'div', { style: { position: 'absolute', inset: 0, background: '#000' } },
      React.createElement('img', { src: 'media/AGM_8.webp', alt: '', style: { position: 'absolute', inset: 0, width: '100%', height: '100%', objectFit: 'cover', transform: 'scale(' + bgScale + ')' } }),
      React.createElement('div', { style: { position: 'absolute', inset: 0, background: '#000', opacity: scrimOp } }),
      React.createElement('img', { src: 'media/AGM_8.2.webp', alt: '', style: { position: 'absolute', left: '50%', top: '50%', width: 'min(66vw,60vh)', height: 'auto', transform: 'translate(-50%,-50%) scale(' + logoScale + ')', filter: 'blur(' + logoBlur + 'px)', opacity: logoOp } })
    )
  );
}

function FullSequence() {
  return React.createElement(
    window.SceneStage,
    { width: 1920, height: 1080, scenes: window.OM_SCENES, playback: window.OM_PLAYBACK, bg: '#000' },
    {
      Intro: IntroScene,
      TechGrid: TechGridScene,
      Truck: TruckScene,
      GridLogo: GridLogoScene,
      Boat: BoatScene,
      Flyer: FlyerScene,
      Outro: OutroScene
    }
  );
}

window.FullSequence = FullSequence;
