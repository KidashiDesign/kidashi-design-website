function ZoomPan(props) {
  const scene = props.scene;
  const { progress } = window.useScene();
  const p = scene.dir === 'in' ? progress : 1 - progress;
  const eased = window.Easing.easeInOutSine(p);
  const scale = 1 + 0.14 * eased;
  const tx = -3 * eased;
  const ty = 2 * eased;
  return React.createElement(
    'div',
    { style: { position: 'absolute', inset: 0, overflow: 'hidden', background: '#000' } },
    React.createElement('img', {
      src: 'uploads/AGM_5.webp',
      style: {
        position: 'absolute',
        top: '50%',
        left: '50%',
        width: '100%',
        height: '100%',
        objectFit: 'cover',
        transform: 'translate(-50%, -50%) translate(' + tx + '%, ' + ty + '%) scale(' + scale + ')',
        transformOrigin: 'center center'
      }
    })
  );
}

function BoatZoomStage() {
  return React.createElement(
    window.SceneStage,
    { width: 1920, height: 1080, scenes: window.OM_SCENES, playback: window.OM_PLAYBACK, bg: '#000' },
    { ZoomIn: ZoomPan, ZoomOut: ZoomPan }
  );
}

window.BoatZoomStage = BoatZoomStage;
