// Header hero scene: full-bleed Ken Burns zoom + subtle 3D deform on the brochure shot.
function HeaderScene(props) {
  var progress = props.progress || 0;
  var t = window.useTweaks(window.TWEAK_DEFAULTS);
  var vals = t[0], setTweak = t[1];
  var zf = (vals.zoomAmount != null ? vals.zoomAmount : 40) / 100;
  var df = (vals.deformAmount != null ? vals.deformAmount : 0) / 100;

  var wave = Math.sin(progress * Math.PI);       // 0 -> 1 -> 0 (breathes once per loop)
  var wave2 = Math.sin(progress * Math.PI * 2);   // 0 -> + -> 0 -> - -> 0 (drift)

  var scale = 1.12 + wave * zf * 0.22;
  var panX = wave2 * zf * 26;
  var panY = wave * zf * -16;
  var rotY = wave2 * df * 7;
  var rotX = -wave * df * 5;

  return React.createElement(
    'div',
    { style: { position: 'absolute', inset: 0, overflow: 'hidden', background: '#dcdcdc', perspective: 2200 } },
    React.createElement('img', {
      src: 'uploads/AGM_6.webp',
      alt: '',
      style: {
        position: 'absolute', inset: '-8%', width: '116%', height: '116%', objectFit: 'cover',
        transform: 'scale(' + scale + ') translate3d(' + panX + 'px,' + panY + 'px,0) rotateX(' + rotX + 'deg) rotateY(' + rotY + 'deg)',
        transformOrigin: 'center center',
      },
    }),
    React.createElement('div', {
      style: { position: 'absolute', inset: 0, boxShadow: 'inset 0 -180px 220px -160px rgba(0,0,0,0.3)', pointerEvents: 'none' },
    }),
    React.createElement(
      window.TweaksPanel,
      null,
      React.createElement(window.TweakSection, { label: 'Motion' }),
      React.createElement(window.TweakSlider, {
        label: 'Zoom', value: vals.zoomAmount != null ? vals.zoomAmount : 40,
        min: 0, max: 100, step: 1, unit: '%',
        onChange: function (v) { setTweak('zoomAmount', v); },
      }),
      React.createElement(window.TweakSlider, {
        label: 'Deform', value: vals.deformAmount != null ? vals.deformAmount : 0,
        min: 0, max: 100, step: 1, unit: '%',
        onChange: function (v) { setTweak('deformAmount', v); },
      }),
      React.createElement(window.TweakToggle, {
        label: 'Motion editor', value: vals.motionEditor !== false,
        onChange: function (v) { setTweak('motionEditor', v); },
      })
    )
  );
}

function HeaderApp() {
  return React.createElement(
    'div',
    { style: { position: 'absolute', inset: 0 } },
    React.createElement(
      window.SceneStage,
      { width: 1920, height: 1080, scenes: window.OM_SCENES, playback: window.OM_PLAYBACK, bg: '#dcdcdc' },
      { Loop: HeaderScene }
    )
  );
}

window.HeaderApp = HeaderApp;
